PixHarvest Customer App - Full Project (Kotlin)
==================================================
This is a ready-to-import Android Studio project for the PixHarvest Customer app.

What it includes:
- Login (Email + Google Sign-In)
- Signup (Email) saving user data to Realtime Database
- Home (product listing & categories)
- Product detail, Cart, Checkout, Orders, Profile
- Firebase integration placeholders (replace google-services.json)

IMPORTANT: You MUST replace `app/google-services.json` with your Firebase config
downloaded from Firebase Console for package `com.pixharvest.customer`.

Your Firebase web config (for reference)
{
  "apiKey": "AIzaSyA5TPkfexV0OAu_YLlY5zVgDTRcuJcPODE",
  "authDomain": "pixharvest-8f0b3.firebaseapp.com",
  "databaseURL": "https://pixharvest-8f0b3-default-rtdb.firebaseio.com",
  "projectId": "pixharvest-8f0b3",
  "storageBucket": "pixharvest-8f0b3.firebasestorage.app",
  "messagingSenderId": "725723341167",
  "appId": "1:725723341167:web:ca4d5b2f83c617511a089a",
  "measurementId": "G-WNFNVW2CQZ"
}

Next steps:
1. Open Android Studio → Open project at this folder
2. Replace app/google-services.json with the real file from Firebase console
3. Set `res/values/strings.xml` -> default_web_client_id to the OAuth client ID present in google-services.json
4. Sync Gradle and run on device/emulator
5. Add SHA-1 to Firebase project for Google Sign-In to work (Android Studio -> Gradle -> signingReport)
