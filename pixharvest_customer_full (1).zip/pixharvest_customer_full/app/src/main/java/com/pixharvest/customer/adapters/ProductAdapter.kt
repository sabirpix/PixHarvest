package com.pixharvest.customer.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.pixharvest.customer.databinding.ItemProductBinding
import com.pixharvest.customer.models.Product

class ProductAdapter(
    private val products: List<Product>,
    private val listener: (Product) -> Unit
) : RecyclerView.Adapter<ProductAdapter.VH>() {

    inner class VH(private val binding: ItemProductBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(p: Product) {
            binding.tvName.text = p.name
            binding.tvPrice.text = "₹ ${'%.2f'.format(p.price)}"
            binding.tvCalories.text = "${p.calories} Calories"
            Glide.with(binding.root.context).load(p.imageUrl).into(binding.ivProduct)
            binding.root.setOnClickListener { listener(p) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemProductBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun getItemCount() = products.size
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(products[position])
}
