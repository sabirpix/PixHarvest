package com.pixharvest.customer.models

data class Product(
    var id: String = "",
    var name: String = "",
    var description: String = "",
    var price: Double = 0.0,
    var calories: Int = 0,
    var imageUrl: String = "",
    var category: String = "",
    var preparation_time: String = ""
)
