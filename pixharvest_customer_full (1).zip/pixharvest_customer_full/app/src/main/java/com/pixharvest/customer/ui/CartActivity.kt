package com.pixharvest.customer.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.pixharvest.customer.databinding.ActivityCartBinding
import com.pixharvest.customer.firebase.FirebaseService

class CartActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCartBinding
    private val items = mutableListOf<Map<String, Any>>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCartBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val uid = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid ?: return
        binding.rvCart.layoutManager = LinearLayoutManager(this)

        FirebaseService.database.child("carts").child(uid).addListenerForSingleValueEvent(object: ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                items.clear()
                for (c in snapshot.children) {
                    val map = c.value as? Map<String, Any>
                    map?.let { items.add(it) }
                }
                binding.tvSummary.text = "Items in cart: ${items.size}"
            }
            override fun onCancelled(error: DatabaseError) {}
        })

        binding.btnCheckout.setOnClickListener {
            val orderRef = FirebaseService.database.child("orders")
            for (it in items) {
                val newOrder = orderRef.push()
                val orderObj = mapOf(
                    "userId" to uid,
                    "productId" to (it["productId"] ?: ""),
                    "name" to (it["name"] ?: ""),
                    "quantity" to (it["quantity"] ?: 1),
                    "status" to "Pending",
                    "createdAt" to System.currentTimeMillis()
                )
                newOrder.setValue(orderObj)
            }
            FirebaseService.database.child("carts").child(uid).removeValue()
            android.widget.Toast.makeText(this, "Order placed", android.widget.Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, OrdersActivity::class.java))
            finish()
        }
    }
}
