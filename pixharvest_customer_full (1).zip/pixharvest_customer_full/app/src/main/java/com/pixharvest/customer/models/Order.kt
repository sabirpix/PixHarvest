package com.pixharvest.customer.models

data class Order(
    var id: String = "",
    var userId: String = "",
    var productId: String = "",
    var name: String = "",
    var quantity: Int = 1,
    var status: String = "Pending",
    var createdAt: Long = 0L,
    var deliveryDetails: String = ""
)
