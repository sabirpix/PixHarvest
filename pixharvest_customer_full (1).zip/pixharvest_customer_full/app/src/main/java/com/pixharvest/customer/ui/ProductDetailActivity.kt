package com.pixharvest.customer.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.pixharvest.customer.databinding.ActivityProductDetailBinding
import com.pixharvest.customer.firebase.FirebaseService
import com.pixharvest.customer.models.Product

class ProductDetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityProductDetailBinding
    private var productId: String? = null
    private var product: Product? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        productId = intent.getStringExtra("product_id")
        productId?.let { loadProduct(it) }

        binding.btnAddToCart.setOnClickListener {
            val uid = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid ?: return@setOnClickListener
            val cartRef = FirebaseService.database.child("carts").child(uid).push()
            val obj = mapOf(
                "productId" to (product?.id ?: ""),
                "name" to (product?.name ?: ""),
                "price" to (product?.price ?: 0.0),
                "quantity" to 1
            )
            cartRef.setValue(obj).addOnSuccessListener {
                android.widget.Toast.makeText(this, "Added to cart", android.widget.Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnOrderNow.setOnClickListener {
            val uid = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid ?: return@setOnClickListener
            val orderRef = FirebaseService.database.child("orders").push()
            val orderObj = mapOf(
                "userId" to uid,
                "productId" to (product?.id ?: ""),
                "name" to (product?.name ?: ""),
                "quantity" to 1,
                "status" to "Pending",
                "createdAt" to System.currentTimeMillis()
            )
            orderRef.setValue(orderObj).addOnSuccessListener {
                android.widget.Toast.makeText(this, "Order placed", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadProduct(id: String) {
        FirebaseService.database.child("products").child(id)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    product = snapshot.getValue(Product::class.java)
                    product?.let { p ->
                        binding.tvTitle.text = p.name
                        binding.tvPrice.text = "₹ ${p.price}"
                        binding.tvDescription.text = p.description
                        binding.tvCalories.text = "${p.calories} Calories"
                        Glide.with(this@ProductDetailActivity).load(p.imageUrl).into(binding.ivProduct)
                    }
                }

                override fun onCancelled(error: DatabaseError) {}
            })
    }
}
