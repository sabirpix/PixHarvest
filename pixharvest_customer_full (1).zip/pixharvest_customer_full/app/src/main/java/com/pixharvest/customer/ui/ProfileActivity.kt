package com.pixharvest.customer.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.pixharvest.customer.databinding.ActivityProfileBinding
import com.pixharvest.customer.firebase.FirebaseService
import com.google.firebase.auth.FirebaseAuth

class ProfileActivity : AppCompatActivity() {
    private lateinit var binding: ActivityProfileBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        FirebaseService.database.child("users").child(uid).get().addOnSuccessListener { snap ->
            val name = snap.child("name").value as? String ?: ""
            val email = snap.child("email").value as? String ?: ""
            binding.tvName.text = name
            binding.tvEmail.text = email
        }

        binding.btnLogout.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            finish()
        }
    }
}
