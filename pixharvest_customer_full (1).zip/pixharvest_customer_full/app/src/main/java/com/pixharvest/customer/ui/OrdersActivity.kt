package com.pixharvest.customer.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.pixharvest.customer.databinding.ActivityOrdersBinding
import com.pixharvest.customer.firebase.FirebaseService
import com.pixharvest.customer.models.Order

class OrdersActivity : AppCompatActivity() {
    private lateinit var binding: ActivityOrdersBinding
    private val orders = mutableListOf<Order>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOrdersBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvOrders.layoutManager = LinearLayoutManager(this)
        val uid = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid ?: return

        FirebaseService.database.child("orders").orderByChild("userId").equalTo(uid)
            .addValueEventListener(object: ValueEventListener{
                override fun onDataChange(snapshot: DataSnapshot) {
                    orders.clear()
                    for (c in snapshot.children) {
                        val o = c.getValue(Order::class.java)
                        o?.id = c.key ?: ""
                        o?.let { orders.add(it) }
                    }
                    binding.tvOrdersSummary.text = "Orders: ${orders.size}"
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }
}
