package com.pixharvest.customer.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.pixharvest.customer.R
import com.pixharvest.customer.adapters.ProductAdapter
import com.pixharvest.customer.databinding.FragmentHomeBinding
import com.pixharvest.customer.firebase.FirebaseService
import com.pixharvest.customer.models.Product

class HomeFragment : Fragment(R.layout.fragment_home) {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val products = mutableListOf<Product>()
    private lateinit var adapter: ProductAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        _binding = FragmentHomeBinding.bind(view)
        binding.rvProducts.layoutManager = GridLayoutManager(context, 2)
        adapter = ProductAdapter(products) { product ->
            val i = Intent(requireContext(), ProductDetailActivity::class.java)
            i.putExtra("product_id", product.id)
            startActivity(i)
        }
        binding.rvProducts.adapter = adapter

        FirebaseService.database.child("products").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                products.clear()
                for (child in snapshot.children) {
                    val p = child.getValue(Product::class.java)
                    p?.id = child.key ?: ""
                    p?.let { products.add(it) }
                }
                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {}
        })

        binding.fabCart.setOnClickListener {
            startActivity(Intent(requireContext(), CartActivity::class.java))
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
