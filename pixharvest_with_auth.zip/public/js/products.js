export const products = [
  { id: 'chitoi', name: 'Chitoi Pitha', desc: 'Handmade chitoi — classic rice cake. Pack of 6.', price: 180, image: 'assets/chitoi.jpg' },
  { id: 'bhapa', name: 'Bhapa Pitha', desc: 'Steamed sweetness — soft and warm. Pack of 8.', price: 260, image: 'assets/bhapa.jpg' },
  { id: 'patishapta', name: 'Patishapta', desc: 'Delicate crepes filled with jaggery & coconut. (12 pcs).', price: 420, image: 'assets/patishapta.jpg' },
  { id: 'giftbox', name: 'Gift Box', desc: 'Deluxe assortment — 24 pcs — perfect for gifting.', price: 750, image: 'assets/giftbox.jpg' }
];