// firebase-config.js
export const firebaseConfig = {
  apiKey: "AIzaSyBi1yCEQKvFLEROaHs8GgndrXZjzvCf-fM",
  authDomain: "pixharvest-2b402.firebaseapp.com",
  databaseURL: "https://pixharvest-2b402-default-rtdb.firebaseio.com",
  projectId: "pixharvest-2b402",
  storageBucket: "pixharvest-2b402.firebasestorage.app",
  messagingSenderId: "947291349569",
  appId: "1:947291349569:web:5623826fe08492dd219cc0",
  measurementId: "G-R5FN13B5M6"
};